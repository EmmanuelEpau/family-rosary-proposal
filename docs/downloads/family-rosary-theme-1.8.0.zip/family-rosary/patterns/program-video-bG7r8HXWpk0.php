<?php
/**
 * Title: Together, even when apart
 * Slug: family-rosary/program-video-bG7r8HXWpk0
 * Categories: family-rosary
 * Inserter: no
 */
?>
<!-- wp:html --><article class="fr-wrap fr-section"><p><a href="../../watch-and-listen/">Watch &amp; Listen</a> / Staying Together: Families Praying Together</p><h1>Together, even when apart</h1><p class="fr-lead">A family reflects on service, sacrifice and the prayer that connects them.</p><div class="program-player"><button class="fr-primary" data-program-embed="https://www.youtube-nocookie.com/embed/bG7r8HXWpk0" data-program-title="Together, even when apart">Play</button></div><dl><dt><strong>Series</strong></dt><dd>Staying Together: Families Praying Together</dd><dt><strong>From</strong></dt><dd>Family Theater Productions</dd><dt><strong>Format</strong></dt><dd>Video</dd><dt><strong>Length</strong></dt><dd>8:01</dd></dl><section><h2>About this episode</h2><p>Family testimony; includes discussion of illness, loss and hardship. Parents should choose what fits their family.</p><p>Original title: Praying Together Through Service and Sacrifice</p><a href="https://www.youtube.com/watch?v=bG7r8HXWpk0">Original program on YouTube</a></section><section><h2>More from Staying Together: Families Praying Together</h2><ul><li><a href="../video-9IsIPuJNdHI/">Faith in the hardest moments</a></li><li><a href="../video-3Hpny2VtT9U/">Trusting God through hardship</a></li><li><a href="../video-8hAd27w4zP0/">Prayer through the storm</a></li><li><a href="../video-aO5K7tBFuaw/">Meet the families</a></li></ul></section></article><!-- /wp:html -->